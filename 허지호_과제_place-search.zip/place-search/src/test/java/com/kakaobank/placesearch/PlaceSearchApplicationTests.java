package com.kakaobank.placesearch;

import com.kakaobank.placesearch.dto.ApiResult;
import com.kakaobank.placesearch.dto.SearchKeywordDto;
import com.kakaobank.placesearch.dto.SearchResultDto;
import com.kakaobank.placesearch.model.SearchKeyword;
import com.kakaobank.placesearch.service.KeywordService;
import lombok.extern.slf4j.Slf4j;
import org.junit.FixMethodOrder;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT
        , properties = "spring.profiles.active=dev"
)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@ActiveProfiles("dev")
@PropertySource("classpath:application-dev.yml")
@Slf4j
class PlaceSearchApplicationTests {
    @LocalServerPort
    int randomServerPort;

    @Autowired
    KeywordService keywordService;

    @Autowired
    RestTemplateBuilder restTemplateBuilder;

    @PersistenceContext
    private EntityManager em;

    @Test
    @DisplayName("[통합테스트]인기 키워드 동시성 테스트")
    void integrationTestPopularKeywordIsolationLevel() {

        //given
        //테스트의 일관성을 유지하기 위해 로딩시 마다 기존 데이터 삭제
        keywordService.clearRedis();

        //when
        /**
         * 동접 테스트를 위해 10개의 thread에서 10번씩 랜덤하게 키워드 요청
         */
        List<SearchClientThread> threads = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            SearchClientThread thread = new SearchClientThread(i + 1);
            thread.start();
            threads.add(thread);
        }


        boolean remainAliveThread = true;
        while (remainAliveThread) {
            remainAliveThread = threads.stream().anyMatch(Thread::isAlive);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ignore) {
            }
        }

        //then
        Query kQuery = em.createQuery("select k from SearchKeyword k order by k.cnt desc");
        List<SearchKeyword> result = kQuery.getResultList();
        StringBuilder sb = new StringBuilder();
        sb.append("\n최종 인기 키워드 순위\n");
        for (int idx = 0; idx < result.size(); idx++) {
            SearchKeyword keyword = result.get(idx);
            sb.append(idx + 1).append(" 위: ").append(keyword.getKeyword())
                    .append(", 검색횟수: ").append(keyword.getCnt()).append("\n");
        }
        log.info(sb.toString());

    }


    /**
     * 검색 클라이언트 Thread
     */
    class SearchClientThread extends Thread {
        Random random = new Random();
        String[] keywords = {"곱창", "식당", "은행", "삼겹살", "피자", "치킨", "소고기"};
        private final int clientId;

        public SearchClientThread(int clientId) {
            this.clientId = clientId;
            //Thread의 생성순서와 상관없이 실행되도록 Priority 적용
            this.setPriority(random.nextInt(Thread.MAX_PRIORITY - Thread.MIN_PRIORITY) + 1);
        }

        @Override
        public void run() {
            RestTemplate restTemplate = restTemplateBuilder.build();
            //10번의 키워드 검색
            for (int i = 0; i < 10; i++) {
                //키워드는 0~ keywords.length 중 랜덤 선택
                int keywordIdx = random.nextInt(keywords.length - 1) + 1;
                String searchKeyword = keywords[keywordIdx];
                restTemplate.exchange("http://localhost:" + randomServerPort + "/v1/search?q=" + searchKeyword, HttpMethod.GET, null, ApiResult.class);

                //인기 키워드 검색
                ResponseEntity<ApiResult<List<SearchKeywordDto>>> response =
                        restTemplate.exchange("http://localhost:" + randomServerPort + "/v1/keyword", HttpMethod.GET, null, new ParameterizedTypeReference<>() {
                        });
                if (response.hasBody()) {
                    List<SearchKeywordDto> result = response.getBody().getData();
                    if (result != null) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("\n키워드 검색: 검색자 - Client ").append(this.clientId)
                                .append("\n검색 키워드: ").append(searchKeyword)
                                .append("\n ** 현재 검색어 순위 **\n");
                        for (int idx = 0; idx < result.size(); idx++) {
                            SearchKeywordDto keyword = result.get(idx);
                            sb.append(idx + 1).append("위: ").append(keyword.getKeyword())
                                    .append(", 검색횟수: ").append(keyword.getCnt()).append("\n");
                        }
                        log.info(sb.toString());
                    }
                }

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {

                }
            }

        }
    }

    /**
     * 인기 검색어 찾는 Thread
     */
    class GetPopularClientThread extends Thread {
        Random random = new Random();

        public GetPopularClientThread() {
            //Thread의 생성순서와 상관없이 실행되도록 Priority 적용
            this.setPriority(random.nextInt(Thread.MAX_PRIORITY - Thread.MIN_PRIORITY) + 1);
        }

        @Override
        public void run() {
            RestTemplate restTemplate = restTemplateBuilder.build();
            ResponseEntity<ApiResult<List<SearchKeywordDto>>> response =
                    restTemplate.exchange("http://localhost:" + randomServerPort + "/v1/keyword", HttpMethod.GET, null, new ParameterizedTypeReference<>() {
                    });
            if (response.hasBody()) {
                log.info(response.getBody().getData().get(0).getKeyword());
            }
        }
    }
}
