package com.kakaobank.placesearch.service;

import com.kakaobank.placesearch.dto.SearchKeywordDto;
import com.kakaobank.placesearch.repository.SearchKeywordRepository;
import com.kakaobank.placesearch.service.impl.KeywordServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@SpringBootTest
@DisplayName("키워드 Service Test")
class KeywordServiceTest {

    @Autowired
    StringRedisTemplate redisTemplate;

    @Autowired
    KeywordServiceImpl keywordService;

    SearchKeywordRepository searchKeywordRepository;

    private final String REDIS_KEY = "popular";

    @BeforeEach
    void setup() {
        redisTemplate.delete(REDIS_KEY);
    }

    @Test
    @DisplayName("키워드 저장 테스트")
    void testSaveKeyword() {
        keywordService.saveKeyword("곱창");
        ZSetOperations<String, String> popularSet = redisTemplate.opsForZSet();
        Long count = popularSet.size(REDIS_KEY);

        assertThat(count, is(1L));
    }

    @Test
    @DisplayName("인기 검색어 확인")
    void testPopularKeyword() {

        //given
        for (int i = 0; i < 10; i++) {
            keywordService.saveKeyword("곱창");
            if (i % 2 == 0)
                keywordService.saveKeyword("은행");

            if (i % 3 == 0)
                keywordService.saveKeyword("식당");

            keywordService.saveKeyword("곱창" + i);
        }

        //when
        List<SearchKeywordDto> searchKeywordDtos = keywordService.popularKeyword();

        //then
        ZSetOperations<String, String> popularSet = redisTemplate.opsForZSet();
        Long count = popularSet.size(REDIS_KEY);

        assertThat(searchKeywordDtos.size(), is(10));
        assertThat(searchKeywordDtos.get(0).getKeyword(), is("곱창"));
        assertThat(searchKeywordDtos.get(1).getKeyword(), is("은행"));
        assertThat(searchKeywordDtos.get(2).getKeyword(), is("식당"));
        //곱창, 은행, 식당, 곱창0~9
        assertThat(count, is(13L));
    }
}