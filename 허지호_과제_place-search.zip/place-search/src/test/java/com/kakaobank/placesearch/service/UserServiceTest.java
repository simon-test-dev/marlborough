package com.kakaobank.placesearch.service;

import com.kakaobank.placesearch.repository.UserRepository;
import com.kakaobank.placesearch.repository.UserSearchHistoryRepository;
import com.kakaobank.placesearch.service.impl.UserServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@ExtendWith(MockitoExtension.class)
@DisplayName("User Service Test")
class UserServiceTest {
    @Mock
    UserRepository userRepository;
    @Mock
    UserSearchHistoryRepository userSearchHistoryRepository;

    @InjectMocks
    UserServiceImpl userService;

    @Test
    @DisplayName("단방향 암호화 테스트")
    void testOnewayCrypto() {
        //given
        String rawData = "kakaobank";
        String c1 = userService.cryptoString(rawData);

        //when
        String c2 = userService.cryptoString(rawData);

        //then
        assertThat(c1, is(c2));
    }
}