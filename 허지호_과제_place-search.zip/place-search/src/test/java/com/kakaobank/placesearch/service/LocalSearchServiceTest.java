package com.kakaobank.placesearch.service;

import com.kakaobank.placesearch.dto.SearchResultDto;
import com.kakaobank.placesearch.exception.OpenApiException;
import com.kakaobank.placesearch.service.impl.LocalSearchServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("검색 Service Test")
class LocalSearchServiceTest {

    @Spy
    @InjectMocks
    LocalSearchServiceImpl localSearchService;

    @Test
    @DisplayName("[곱창]검색 테스트")
    void testSearch() throws OpenApiException {

        //give
        List<SearchResultDto> kakaoList = new ArrayList<>();
        kakaoList.add(SearchResultDto.builder().title("A곱창").build());
        kakaoList.add(SearchResultDto.builder().title("B곱창").build());
        kakaoList.add(SearchResultDto.builder().title("C곱창").build());
        kakaoList.add(SearchResultDto.builder().title("D곱창").build());
        List<SearchResultDto> naverList = new ArrayList<>();
        naverList.add(SearchResultDto.builder().title("A곱창").build());
        naverList.add(SearchResultDto.builder().title("E곱창").build());
        naverList.add(SearchResultDto.builder().title("D곱창").build());
        naverList.add(SearchResultDto.builder().title("C곱창").build());

        //when
        doReturn(kakaoList).when(localSearchService).kakaoSearch(anyString());
        doReturn(naverList).when(localSearchService).naverSearch(anyString());

        //then
        List<SearchResultDto> result = localSearchService.search("곱창");
        Optional<String> resultStr = result.stream().map(SearchResultDto::getTitle).reduce((a, b) -> a + ',' + b);
        assertTrue(resultStr.isPresent());
        assertThat(resultStr.get(), is("A곱창,C곱창,D곱창,B곱창,E곱창"));

    }
    @Test
    @DisplayName("[은행]검색 테스트")
    void testSearch2() throws OpenApiException {

        //give
        List<SearchResultDto> kakaoList = new ArrayList<>();
        kakaoList.add(SearchResultDto.builder().title("카카오뱅크").build());
        kakaoList.add(SearchResultDto.builder().title("우리은행").build());
        kakaoList.add(SearchResultDto.builder().title("국민은행").build());
        kakaoList.add(SearchResultDto.builder().title("부산은행").build());
        kakaoList.add(SearchResultDto.builder().title("새마을금고").build());
        List<SearchResultDto> naverList = new ArrayList<>();
        naverList.add(SearchResultDto.builder().title("카카오뱅크").build());
        naverList.add(SearchResultDto.builder().title("부산은행").build());
        naverList.add(SearchResultDto.builder().title("하나은행").build());
        naverList.add(SearchResultDto.builder().title("국민은행").build());
        naverList.add(SearchResultDto.builder().title("기업은행").build());

        //when
        doReturn(kakaoList).when(localSearchService).kakaoSearch(anyString());
        doReturn(naverList).when(localSearchService).naverSearch(anyString());

        //then
        List<SearchResultDto> result = localSearchService.search("은행");
        Optional<String> resultStr = result.stream().map(SearchResultDto::getTitle).reduce((a, b) -> a + ',' + b);
        assertTrue(resultStr.isPresent());
        assertThat(resultStr.get(), is("카카오뱅크,국민은행,부산은행,우리은행,새마을금고,하나은행,기업은행"));

    }
}