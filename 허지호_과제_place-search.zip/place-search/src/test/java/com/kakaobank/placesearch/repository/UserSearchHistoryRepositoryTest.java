package com.kakaobank.placesearch.repository;

import com.kakaobank.placesearch.dto.SearchHistoryDto;
import com.kakaobank.placesearch.model.User;
import com.kakaobank.placesearch.model.UserSearchHistory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.PageRequest;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

@DataJpaTest
@DisplayName("사용자 검색 히스토리 Repository Test")
class UserSearchHistoryRepositoryTest {

    @Autowired
    UserRepository userRepository;
    @Autowired
    UserSearchHistoryRepository userSearchHistoryRepository;

    @Test
    @DisplayName("사용자 검색 히스토리 테스트")
    void testSearchHistory() {

        //given
        String username = "prographer.j@gmail.com";
        User user = User.builder()
                .username(username)
                .password("1234")
                .build();

        user.addUserSearchHistory(
                UserSearchHistory.builder()
                        .keyword("곱창")
                        .build());

        userRepository.save(user);

        //when
        List<SearchHistoryDto> searchHistory = userSearchHistoryRepository.getSearchHistory(username, PageRequest.of(0, 10));

        //then
        assertThat(searchHistory.size(), is(1));

    }
}