package com.kakaobank.placesearch.controller;

import com.kakaobank.placesearch.dto.SearchResultDto;
import com.kakaobank.placesearch.service.KeywordService;
import com.kakaobank.placesearch.service.LocalSearchService;
import com.kakaobank.placesearch.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LocalSearchController.class)
@DisplayName("LocalSearch Controller Test")
class LocalSearchControllerTest extends BaseMvcTest {
    @MockBean
    private LocalSearchService localSearchService;

    @MockBean
    private UserService userService;

    @MockBean
    private KeywordService keywordService;

    @Test
    @DisplayName("검색 테스트")
    void testSearch() throws Exception {
        //given
        List<SearchResultDto> searchResultDtoList = new ArrayList<>();
        given(localSearchService.search(anyString())).willReturn(searchResultDtoList);

        //when
        final ResultActions actions = mvc.perform(get("/v1/search?q=곱창")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.resultCode", is(200)))
                .andDo(print());
    }
}