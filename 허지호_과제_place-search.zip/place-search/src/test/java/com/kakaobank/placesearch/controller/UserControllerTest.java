package com.kakaobank.placesearch.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kakaobank.placesearch.dto.LoginDto;
import com.kakaobank.placesearch.dto.SearchHistoryDto;
import com.kakaobank.placesearch.dto.SignUpDto;
import com.kakaobank.placesearch.exception.NotFoundException;
import com.kakaobank.placesearch.model.UserSearchHistory;
import com.kakaobank.placesearch.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultActions;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UserController.class)
@DisplayName("User Controller Test")
class UserControllerTest extends BaseMvcTest {
    @MockBean
    private UserService userService;

    @Test
    @DisplayName("회원가입 테스트")
    void testSignup() throws Exception {
        //given
        SignUpDto signUpDto = SignUpDto.builder().username("prographer.j@gmail.com").password("test1234").build();

        //when
        doNothing().when(userService).signup(any(SignUpDto.class));
        final ResultActions actions = mvc.perform(post("/v1/user/signup")
                .content(new ObjectMapper().findAndRegisterModules().writeValueAsString(signUpDto))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.resultCode", is(200)))
                .andDo(print());
    }


    @Test
    @DisplayName("로그인 테스트")
    void testLogin() throws Exception {

        //given
        String token = "test-token-1234";
        LoginDto loginDto = LoginDto.builder().username("prographer.j@gmail.com").password("test1234").build();
        given(userService.login(any(LoginDto.class))).willReturn(token);

        //when
        final ResultActions actions = mvc.perform(post("/v1/user/login")
                .content(new ObjectMapper().findAndRegisterModules().writeValueAsString(loginDto))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.data", is(token)))
                .andDo(print());
    }

    @Test
    @DisplayName("내 검색 히스토리")
    void testMyHistory() throws Exception {

        //given
        List<SearchHistoryDto> searchHistory = new ArrayList<>();
        searchHistory.add(SearchHistoryDto.builder()
                .keyword("곱창")
                .searchAt(LocalDateTime.now().minusDays(1)).build());

        given(userService.searchHistory(anyString())).willReturn(searchHistory);
        //when
        final ResultActions actions = mvc.perform(get("/v1/user/history/")
                .contentType(MediaType.APPLICATION_JSON)
                .header("X-TOKEN", "test-token")).andDo(print());

        //then
        actions.andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.resultCode", is(200)))
                .andDo(print());

    }
}