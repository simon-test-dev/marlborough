package com.kakaobank.placesearch.repository;

import com.kakaobank.placesearch.model.SearchKeyword;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@DisplayName("검색키워드 Repository Test")
class SearchKeywordRepositoryTest {
    @Autowired
    SearchKeywordRepository searchKeywordRepository;

    @Test
    @DisplayName("키워드 등록여부 확인")
    void testExistsByKeyword() {
        //given
        String keyword = "곱창";
        searchKeywordRepository.save(SearchKeyword.builder()
                .keyword(keyword)
                .build());
        //when
        Boolean existsKeyword = searchKeywordRepository.existsByKeyword(keyword);

        //then
        assertTrue(existsKeyword);
    }

    @Test
    @DisplayName("키워드 검색 카운트 증가 확인")
    void testAddSearchKeywordCnt() {
        //given
        String keyword = "곱창";
        searchKeywordRepository.save(SearchKeyword.builder()
                .keyword(keyword)
                .build());
        searchKeywordRepository.addSearchKeywordCnt(keyword);
        //when
        Optional<SearchKeyword> findKeyword = searchKeywordRepository.findById(keyword);
        //then
        assertTrue(findKeyword.isPresent());
        assertThat(findKeyword.get().getCnt(), is(2));
    }
}