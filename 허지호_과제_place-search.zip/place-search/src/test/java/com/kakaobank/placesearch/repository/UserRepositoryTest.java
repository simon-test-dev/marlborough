package com.kakaobank.placesearch.repository;

import com.kakaobank.placesearch.model.User;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@DisplayName("사용자 Repository Test")
class UserRepositoryTest {

    @Autowired
    UserRepository userRepository;

    @Test
    @DisplayName("중복된 username 확인")
    void testExistsByUsername() {
        //given
        String username = "prographer.j@gmail.com";
        userRepository.save(User.builder()
                .username(username)
                .password("1234")
                .build());

        //when
        Boolean existsUsername = userRepository.existsByUsername(username);

        //then
        assertTrue(existsUsername);
    }

    @Test
    @DisplayName("토큰의 유효성 검사")
    void testValidationLoginToken() {

        //given
        String username = "prographer.j@gmail.com";
        userRepository.save(User.builder()
                .username(username)
                .password("1234")
                .loginToken("test-token-1234")
                .tokenExpire(LocalDateTime.now().plusDays(1))
                .build());

        //when
        Optional<User> findUser = userRepository.findByLoginTokenAndTokenExpireIsGreaterThanEqual("test-token-1234", LocalDateTime.now());

        //then
        assertTrue(findUser.isPresent());
    }

}