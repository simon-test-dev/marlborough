package com.kakaobank.placesearch.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;

/**
 * 검색결과
 */
@AllArgsConstructor
@Builder
@Data
public class SearchResultDto implements Serializable {
    private static final long serialVersionUID = 1828951224883451461L;
    private String title;
    private String address;

    //정렬을 위한 필드
    @JsonIgnore
    private int score;
    @JsonIgnore
    private int idx;

    @JsonCreator
    public SearchResultDto(@JsonProperty("title") String title, @JsonProperty("address") String address) {
        this.title = title;
        this.address = address;
    }
}
