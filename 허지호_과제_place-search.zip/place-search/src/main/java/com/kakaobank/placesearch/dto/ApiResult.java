package com.kakaobank.placesearch.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ApiResult<T> {

    public static int OK = 200;
    public static int NOT_FOUND = 404;
    public static int ERROR = 500;

    T data;
    String resultMessage;
    int resultCode;

    public ApiResult(T data) {
        this.data = data;
        this.resultCode = OK;
        this.resultMessage = OK + " OK";
    }

    public ApiResult(int resultCode, String resultMessage) {
        this.resultMessage = resultMessage;
        this.resultCode = resultCode;
    }
}
