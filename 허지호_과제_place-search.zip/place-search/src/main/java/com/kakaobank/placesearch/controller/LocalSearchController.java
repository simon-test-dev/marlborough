package com.kakaobank.placesearch.controller;

import com.kakaobank.placesearch.dto.ApiResult;
import com.kakaobank.placesearch.dto.SearchResultDto;
import com.kakaobank.placesearch.exception.NotFoundException;
import com.kakaobank.placesearch.exception.OpenApiException;
import com.kakaobank.placesearch.service.KeywordService;
import com.kakaobank.placesearch.service.LocalSearchService;
import com.kakaobank.placesearch.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("v1/search")
@RequiredArgsConstructor
public class LocalSearchController {

    private final LocalSearchService localSearchService;
    private final UserService userService;
    private final KeywordService keywordService;

    @GetMapping
    public ApiResult<List<SearchResultDto>> search(
            @RequestHeader(value = "X-TOKEN", required = false) String token,
            @RequestParam("q") String q) {

        try {
            //사용자의 검색 정보를 저장한다.
            //하지만 token이 만료 되었거나, token이 없을 경우는 저장을 안한다.
            if (token != null)
                userService.saveHistory(token, q);
        } catch (NotFoundException ignore) {
        }

        //키워드 저장
        keywordService.saveKeyword(q);

        //검색
        List<SearchResultDto> result = null;
        try {
            result = localSearchService.search(q);
        } catch (OpenApiException e) {
            new ApiResult<>(ApiResult.ERROR, e.getApiType() + " Api Error");
        }
        return new ApiResult<>(result);
    }
}
