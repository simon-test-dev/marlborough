package com.kakaobank.placesearch.dto;

import com.kakaobank.placesearch.model.SearchKeyword;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchKeywordDto {

    private String keyword;
    @Builder.Default
    private int cnt = 1;

    public SearchKeywordDto(SearchKeyword k) {
        this.keyword = k.getKeyword();
        this.cnt = k.getCnt();
    }
}
