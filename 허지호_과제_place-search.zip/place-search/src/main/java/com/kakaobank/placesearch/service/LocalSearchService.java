package com.kakaobank.placesearch.service;

import com.kakaobank.placesearch.dto.SearchResultDto;
import com.kakaobank.placesearch.exception.OpenApiException;

import java.util.List;

public interface LocalSearchService {
    /**
     * 장소검색
     * @param q 검색어
     * @return 검색결과
     */
    List<SearchResultDto> search(String q) throws OpenApiException;

}
