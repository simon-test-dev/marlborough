package com.kakaobank.placesearch.controller;

import com.kakaobank.placesearch.dto.ApiResult;
import com.kakaobank.placesearch.dto.SearchKeywordDto;
import com.kakaobank.placesearch.service.KeywordService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("v1/keyword")
@RequiredArgsConstructor
public class KeywordController {

    private final KeywordService keywordService;

    @GetMapping
    public ApiResult<List<SearchKeywordDto>> popularKeyword() {
        List<SearchKeywordDto> searchKeywords = keywordService.popularKeyword();
        return new ApiResult<>(searchKeywords);

    }
}
