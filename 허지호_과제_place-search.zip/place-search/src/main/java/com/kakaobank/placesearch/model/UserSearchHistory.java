package com.kakaobank.placesearch.model;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class UserSearchHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(AccessLevel.PRIVATE)
    private Long historyId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column
    private String keyword;

    @Column(updatable = false)
    @Setter(AccessLevel.PRIVATE)
    private LocalDateTime searchedAt;

    @PrePersist
    public void beforePersist() {
        this.searchedAt = LocalDateTime.now();
    }

    @Builder
    public UserSearchHistory(String keyword) {
        this.keyword = keyword;
    }
}
