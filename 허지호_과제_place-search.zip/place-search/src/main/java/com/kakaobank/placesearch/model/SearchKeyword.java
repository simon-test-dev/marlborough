package com.kakaobank.placesearch.model;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchKeyword {

    @Id
    @Column
    private String keyword;

    @Builder.Default
    private int cnt = 1;
}
