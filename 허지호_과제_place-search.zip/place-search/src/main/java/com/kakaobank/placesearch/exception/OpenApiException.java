package com.kakaobank.placesearch.exception;

import lombok.Getter;

public class OpenApiException extends Exception {
    public static String Kakao = "Kakao";
    public static String Naver = "Naver";

    @Getter
    private String apiType;

    public OpenApiException(String apiType) {
        this.apiType = apiType;
    }
}
