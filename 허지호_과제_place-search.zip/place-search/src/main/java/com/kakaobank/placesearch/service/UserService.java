package com.kakaobank.placesearch.service;

import com.kakaobank.placesearch.dto.LoginDto;
import com.kakaobank.placesearch.dto.SearchHistoryDto;
import com.kakaobank.placesearch.dto.SignUpDto;
import com.kakaobank.placesearch.exception.AlreadyUsername;
import com.kakaobank.placesearch.exception.NotFoundException;

import java.util.List;

public interface UserService {
    /**
     * 회원가입
     *
     * @param signUpDto 회원강비 정보
     */
    void signup(SignUpDto signUpDto) throws AlreadyUsername;

    /**
     * 로그인
     *
     * @param loginDto 로그인 정보
     * @return 로그인 결과
     */
    String login(LoginDto loginDto) throws NotFoundException;


    /**
     * 사용자의 검색 히스토리
     *
     * @param token 사용자 토큰
     * @return 검색결과
     */
    List<SearchHistoryDto> searchHistory(String token) throws NotFoundException;

    void saveHistory(String token, String q) throws NotFoundException;

    /**
     * 암호화 알고리즘
     *
     * @param raw 원본데이터
     * @return 암호화 결과
     */
    String cryptoString(String raw);
}
