package com.kakaobank.placesearch.dto;

import lombok.*;

/**
 * 로그인 DTO
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoginDto {
    private String username;
    private String password;
}
