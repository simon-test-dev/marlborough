package com.kakaobank.placesearch.service.impl;

import com.kakaobank.placesearch.dto.SearchResultDto;
import com.kakaobank.placesearch.exception.OpenApiException;
import com.kakaobank.placesearch.service.LocalSearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
@RequiredArgsConstructor
public class LocalSearchServiceImpl implements LocalSearchService {

    private final RestTemplateBuilder restTemplateBuilder;

    @Value("${kakao.rest-api-key}")
    String kakaoApiKey;
    @Value("${kakao.url}")
    String kakaoUrl;

    @Value("${naver.url}")
    String naverUrl;
    @Value("${naver.client-id}")
    String naverClientId;
    @Value("${naver.client-secret}")
    String naverClientSecret;

    @Override

    @Cacheable(value = "search", key = "#q")
    public List<SearchResultDto> search(String q) throws OpenApiException {

        List<SearchResultDto> kakao;
        List<SearchResultDto> naver;
        try {
            kakao = kakaoSearch(q);
        } catch (RestClientException e) {
            throw new OpenApiException(OpenApiException.Kakao);
        }
        try {
            naver = naverSearch(q);
        } catch (RestClientException e) {
            throw new OpenApiException(OpenApiException.Naver);
        }

        List<SearchResultDto> result = new ArrayList<>();
        for (SearchResultDto k : kakao) {
            if (naver.removeIf(n -> n.getTitle().equals(k.getTitle()))) {
                k.setScore(k.getScore() + 1);
            }
        }
        result.addAll(kakao);
        result.addAll(naver);

        //정렬
        result.sort((o1, o2) -> {
            // score가 같을 경우 idx가 작은순(먼저 검색결과가 노출된 순서)
            if (o1.getScore() == o2.getScore()) {
                if (o1.getIdx() < o2.getIdx())
                    return -1;
                else if (o1.getIdx() > o2.getIdx())
                    return 1;
            } else {
                //그렇지 않을 겨우는 스코어가 큰순으로 정렬
                if (o1.getScore() > o2.getScore())
                    return -1;
                else if (o1.getScore() < o2.getScore())
                    return 1;
            }
            return 0;
        });

        return result;
    }

    /**
     * Kakao 키워드 검색
     *
     * @param q 검색어
     * @return 검색 결과
     */
    public List<SearchResultDto> kakaoSearch(String q) throws RestClientException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.AUTHORIZATION, "KakaoAK " + kakaoApiKey);
        HttpEntity<?> entity = new HttpEntity<>(headers);
        RestTemplate restTemplate = restTemplateBuilder.build();

        String url = String.format("%s?query=%s&size=10", kakaoUrl, q);
        ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);
        List<SearchResultDto> result = new ArrayList<>();
        if (response.hasBody()) {
            List documents = (List) Objects.requireNonNull(response.getBody()).get("documents");
            int idx = 0;
            for (Object o : documents) {
                Map<String, String> doc = (Map) o;
                result.add(SearchResultDto.builder()
                        .title(doc.get("place_name"))
                        .address(doc.get("address_name"))
                        .score(2)// Score 1점
                        .idx(idx++) // 동일한 Score 해결을 위한 순서값 저장
                        .build());
            }
        }
        return result;

    }

    /**
     * Naver 키워드 검색
     *
     * @param q 검색어
     * @return 검색 결과
     */
    public List<SearchResultDto> naverSearch(String q) throws RestClientException {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add("X-Naver-Client-Id", naverClientId);
        headers.add("X-Naver-Client-Secret", naverClientSecret);

        HttpEntity<?> entity = new HttpEntity<>(headers);
        RestTemplate restTemplate = restTemplateBuilder.build();

        String url = String.format("%s?query=%s&display=5", naverUrl, q);
        ResponseEntity<Map> response = restTemplate.exchange(url, HttpMethod.GET, entity, Map.class);
        List<SearchResultDto> result = new ArrayList<>();

        if (response.hasBody()) {
            List documents = (List) Objects.requireNonNull(response.getBody()).get("items");
            int idx = 0;
            for (Object o : documents) {
                Map<String, String> doc = (Map) o;
                result.add(SearchResultDto.builder()
                        .title(doc.get("title").replaceAll("</?b>", "")) //검색 결과를 동일하게 하기 위해 태그 삭제
                        .address(doc.get("address"))
                        .score(1) // Score 1점
                        .idx(idx++) // 동일한 Score 해결을 위한 순서값 저장
                        .build());
            }
        }
        return result;
    }
}
