package com.kakaobank.placesearch.repository;

import com.kakaobank.placesearch.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Boolean existsByUsername(String username);

    Optional<User> findByLoginTokenAndTokenExpireIsGreaterThanEqual(String token, LocalDateTime today);
    Optional<User> findByUsernameAndPassword(String username, String password);

}
