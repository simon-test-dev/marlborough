package com.kakaobank.placesearch.repository;

import com.kakaobank.placesearch.model.SearchKeyword;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public interface SearchKeywordRepository extends JpaRepository<SearchKeyword, String> {

    Boolean existsByKeyword(String keyword);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SearchKeyword k set k.cnt = k.cnt+1 where k.keyword=:keyword")
    void addSearchKeywordCnt(@Param("keyword") String keyword);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query("update SearchKeyword k set k.cnt = k.cnt+:cnt where k.keyword=:keyword")
    void addSearchKeywordCnt(@Param("keyword") String keyword, @Param("cnt") int cnt);
}
