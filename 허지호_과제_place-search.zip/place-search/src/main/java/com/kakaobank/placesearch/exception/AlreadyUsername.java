package com.kakaobank.placesearch.exception;

public class AlreadyUsername extends Exception {

}
