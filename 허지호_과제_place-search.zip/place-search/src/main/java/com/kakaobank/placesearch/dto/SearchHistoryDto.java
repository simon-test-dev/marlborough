package com.kakaobank.placesearch.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter

public class SearchHistoryDto {
    private String keyword;
    private LocalDateTime searchAt;

    @Builder
    public SearchHistoryDto(String keyword, LocalDateTime searchAt) {
        this.keyword = keyword;
        this.searchAt = searchAt;
    }
}
