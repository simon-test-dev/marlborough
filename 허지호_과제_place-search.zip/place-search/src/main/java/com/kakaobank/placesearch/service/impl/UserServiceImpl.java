package com.kakaobank.placesearch.service.impl;

import com.kakaobank.placesearch.dto.LoginDto;
import com.kakaobank.placesearch.dto.SearchHistoryDto;
import com.kakaobank.placesearch.dto.SignUpDto;
import com.kakaobank.placesearch.exception.AlreadyUsername;
import com.kakaobank.placesearch.exception.NotFoundException;
import com.kakaobank.placesearch.model.User;
import com.kakaobank.placesearch.model.UserSearchHistory;
import com.kakaobank.placesearch.repository.UserRepository;
import com.kakaobank.placesearch.repository.UserSearchHistoryRepository;
import com.kakaobank.placesearch.service.UserService;
import lombok.RequiredArgsConstructor;
import net.bytebuddy.utility.RandomString;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserSearchHistoryRepository userSearchHistoryRepository;

    @Override
    @Transactional
    public void signup(SignUpDto signUpDto) throws AlreadyUsername {
        boolean isAlready = userRepository.existsByUsername(signUpDto.getUsername());
        if (isAlready) throw new AlreadyUsername();

        User user = User.builder()
                .username(signUpDto.getUsername())
                .password(cryptoString(signUpDto.getPassword()))
                .build();

        userRepository.save(user);

    }

    @Override
    @Transactional
    public String login(LoginDto loginDto) throws NotFoundException {
        Optional<User> findUser = userRepository.findByUsernameAndPassword(loginDto.getUsername(), cryptoString(loginDto.getPassword()));
        if (findUser.isEmpty()) throw new NotFoundException("User Not Found");
        //로그인 토큰 발행
        User user = findUser.get();
        user.setLoginToken(cryptoString(RandomString.make()));
        user.setTokenExpire(LocalDateTime.now().plusDays(1));

        return user.getLoginToken();
    }

    @Override
    public List<SearchHistoryDto> searchHistory(String token) throws NotFoundException {
        Optional<User> findUser = userRepository.findByLoginTokenAndTokenExpireIsGreaterThanEqual(token, LocalDateTime.now());
        if (findUser.isEmpty()) throw new NotFoundException();
        return userSearchHistoryRepository.getSearchHistory(findUser.get().getUsername(), PageRequest.of(0, 10));
    }

    @Override
    @Transactional
    public void saveHistory(String token, String q) throws NotFoundException {

        Optional<User> findUser = userRepository.findByLoginTokenAndTokenExpireIsGreaterThanEqual(token, LocalDateTime.now());
        if (findUser.isEmpty()) throw new NotFoundException();
        User user = findUser.get();
        user.addUserSearchHistory(UserSearchHistory.builder()
                .keyword(q).build());

        userRepository.save(user);
    }

    public String cryptoString(String raw) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(raw.getBytes());
            return String.format("%0128x", new BigInteger(1, md.digest()));
        } catch (NoSuchAlgorithmException ignore) {
        }
        return null;
    }


}
