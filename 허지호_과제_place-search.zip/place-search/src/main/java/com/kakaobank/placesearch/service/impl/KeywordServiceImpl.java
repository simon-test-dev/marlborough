package com.kakaobank.placesearch.service.impl;

import com.kakaobank.placesearch.dto.SearchKeywordDto;
import com.kakaobank.placesearch.model.SearchKeyword;
import com.kakaobank.placesearch.repository.SearchKeywordRepository;
import com.kakaobank.placesearch.service.KeywordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class KeywordServiceImpl implements KeywordService {
    private final String REDIS_POPULAR_KEY = "popular";
    private final String REDIS_SAVE_KEYWORD_KEY = "save_keyword";

    private final SearchKeywordRepository searchKeywordRepository;
    private final StringRedisTemplate redisTemplate;
    private final ZSetOperations<String, String> popularSet;
    private final ListOperations<String, String> keywordSaveList;

    public KeywordServiceImpl(SearchKeywordRepository searchKeywordRepository, StringRedisTemplate redisTemplate) {
        this.searchKeywordRepository = searchKeywordRepository;
        this.redisTemplate = redisTemplate;
        this.popularSet = redisTemplate.opsForZSet();
        this.keywordSaveList = redisTemplate.opsForList();
    }

    @Override
    public void clearRedis() {
        redisTemplate.delete(REDIS_POPULAR_KEY);
        redisTemplate.delete(REDIS_SAVE_KEYWORD_KEY);
    }

    /**
     * DB -> Reids로 데이터 저장
     */
    @PostConstruct
    private void initPopularKeyword() {
        //서버의 비정상 종료로 인해 DB에 저장 못하고 Redis에 남아 있는 데이터 Save
        saveRedisToDb();
        //DB의 값을 Redis Sorted Set에 로드
        Page<SearchKeyword> findPopular = searchKeywordRepository.findAll(PageRequest.of(0, 10, Sort.Direction.DESC, "cnt"));
        findPopular.getContent().forEach(k -> popularSet.add(REDIS_POPULAR_KEY, k.getKeyword(), k.getCnt()));
    }

    /**
     * DB 저장
     */
    @Scheduled(cron = "* * * * * *")
    public void saveRedisToDb() {
        //DB에 저장
        List<String> range = keywordSaveList.range(REDIS_SAVE_KEYWORD_KEY, 0, -1);
        if (range != null) {
            keywordSaveList.trim(REDIS_SAVE_KEYWORD_KEY, range.size(), -1);
            Map<String, Integer> keywordMap = new HashMap<>();
            // 동일한 키워드 분류
            range.forEach(r -> {
                int cnt = 1;
                if (keywordMap.containsKey(r)) {
                    cnt = keywordMap.get(r) + 1;
                }
                keywordMap.put(r, cnt);
            });

            //DB Save
            keywordMap.keySet().forEach(k -> {
                int cnt = keywordMap.get(k);
                Boolean existsKeyword = searchKeywordRepository.existsByKeyword(k);
                if (existsKeyword)
                    searchKeywordRepository.addSearchKeywordCnt(k, cnt);
                else
                    searchKeywordRepository.save(
                            SearchKeyword.builder()
                                    .keyword(k)
                                    .cnt(cnt)
                                    .build());
            });
        }
    }

    @Override
    @Transactional
    public void saveKeyword(String keyword) {
        //Redis에 저장
        popularSet.incrementScore(REDIS_POPULAR_KEY, keyword, 1);
        //DB에 저장을 위한 데이터 쌓기
        keywordSaveList.leftPush(REDIS_SAVE_KEYWORD_KEY, keyword);
    }


    @Override
    public List<SearchKeywordDto> popularKeyword() {
        Set<ZSetOperations.TypedTuple<String>> populars = popularSet.reverseRangeWithScores(REDIS_POPULAR_KEY, 0, 9);

        if (populars != null) {
            return populars.stream()
                    .map(p -> SearchKeywordDto
                            .builder()
                            .keyword(p.getValue())
                            .cnt(Objects.requireNonNull(p.getScore()).intValue())
                            .build())
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }
}
