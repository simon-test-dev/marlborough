package com.kakaobank.placesearch.service;

import com.kakaobank.placesearch.dto.SearchKeywordDto;

import java.util.List;

public interface KeywordService {

    /**
     * 테스트의 일관성을 유지하기 위해 로딩시 마다 기존 데이터 삭제
     */
    void clearRedis();

    /**
     * 키워드 저장
     * @param keyword
     */
    void saveKeyword(String keyword);

    /**
     * 인기검색어
     *
     * @return 사용자들이 많이 검색한 순서대로, 최대 10개의 검색 키워드를 제공
     */
    List<SearchKeywordDto> popularKeyword();

}
