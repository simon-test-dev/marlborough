package com.kakaobank.placesearch.controller;

import com.kakaobank.placesearch.dto.ApiResult;
import com.kakaobank.placesearch.dto.LoginDto;
import com.kakaobank.placesearch.dto.SearchHistoryDto;
import com.kakaobank.placesearch.dto.SignUpDto;
import com.kakaobank.placesearch.exception.AlreadyUsername;
import com.kakaobank.placesearch.exception.NotFoundException;
import com.kakaobank.placesearch.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("v1/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("signup")
    public ApiResult<String> signup(@RequestBody SignUpDto signUpDto) {
        try {
            userService.signup(signUpDto);
            return new ApiResult<>(ApiResult.OK, "회원가입이 완료되었습니다.");
        } catch (AlreadyUsername alreadyUsername) {
            return new ApiResult<>(ApiResult.ERROR, "이미 등록된 사용자입니다.");
        }
    }

    @PostMapping("login")
    public ApiResult<String> login(@RequestBody LoginDto loginDto) {
        try {
            String token = userService.login(loginDto);
            return new ApiResult<>(token);
        } catch (NotFoundException e) {
            return new ApiResult<>(ApiResult.ERROR, "아이디 또는 비밀번호가 틀렸습니다.");
        }
    }

    @GetMapping("history")
    public ApiResult<List<SearchHistoryDto>> getHistory(@RequestHeader("X-TOKEN") String token) {
        try {
            List<SearchHistoryDto> result = userService.searchHistory(token);
            return new ApiResult<>(result);
        } catch (NotFoundException e) {
            return new ApiResult<>(ApiResult.NOT_FOUND, "로그인 후 사용해 주세요.");
        }
    }
}
