package com.kakaobank.placesearch.dto;

import lombok.*;

/**
 * 회원가입
 */
@Getter
@Setter
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class SignUpDto {
    private String username;
    private String password;
}
