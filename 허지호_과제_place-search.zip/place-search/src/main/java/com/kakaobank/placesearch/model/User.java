package com.kakaobank.placesearch.model;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(indexes = {
        @Index(name = "idx_username", columnList = "username")
})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    /**
     * 사용자 계정
     */
    @Column
    private String username;

    /**
     * 비밀번호
     */
    @Column(length = 512)
    private String password;

    @Column(length = 512)
    private String loginToken;

    @Column
    private LocalDateTime tokenExpire;

    @Column(updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime updatedAt;

    @Builder.Default
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("searchedAt desc")
    private List<UserSearchHistory> searchHistory = new ArrayList<>();

    public void addUserSearchHistory(UserSearchHistory ush) {
        if (ush.getUser() == null)
            ush.setUser(this);
        this.searchHistory.add(ush);
    }

    @PrePersist
    public void beforePersist() {
        LocalDateTime dateTime = LocalDateTime.now();
        this.createdAt = dateTime;
        this.updatedAt = dateTime;
    }

    @PreUpdate
    public void beforeUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
