# 핵심 구현 로직 설명
제가 생각하는 이 과제 구현의 핵심은 다음 3가지로 생각됩니다.

1. 2개의 오픈소스 API 사용하여 조건에 맞도록 정렬 
2. 대량의 트래픽 처리
3. 동시성 문제의 해결

이 문제를 해결하기 위한 방법으로 다음과 같이 구현하였습니다.

### 1. 2개의 오픈소스 API 사용 하여 조건에 맞도록 정렬
검색 결과 정렬을 위해 Score라는 값을 정의하였습니다.   
이 값은 기본값(Kakao 2점, Naver 1점)을 갖고 있고 검색 결과를 비교하여 동일한 업체명이 있으면 각 Score를 더하여 정렬 시 우선순위를 높였습니다.  
만일, 동일한 Score를 받은 값을 정렬하기 위하여 순서 값을 추가하였습니다.

<pre>
//LocalSearchServiceImpl.java

// Kakao 검색 결과
private List<SearchResultDto> kekaoSearch(String q) {
    ...
    result.add(
        SearchResultDto.builder()
            .title(doc.get("place_name"))
            .address(doc.get("address_name"))
            .score(2)   // Score 2점
            .idx(idx++) //동일한 Score 해결을 위한 순서값 저장
            .build());
    ...
}

// Naver 키워드 검색
private List<SearchResultDto> naverSearch(String q) {
    ...
    result.add(
        SearchResultDto.builder()
            .title(doc.get("title").replaceAll("</?b>", "")) //검색 결과를 동일하게 하기 위해 태그 삭제
            .address(doc.get("address"))
            .score(1)  // Score 1점
            .idx(idx++) //동일한 Score 해결을 위한 순서값 저장
            .build());
}
</pre> 

값 비교는 Kakao 기준으로 하며 Kakao와 Naver의 동일한 결과가 있으면 Score를 더하고 Naver의 결과는 삭제하도록 구현했습니다.
<pre>
//LocalSearchServiceImpl.java
public List<SearchResultDto> search(String q) {
...
    for (SearchResultDto k : kakao) {
        if (naver.removeIf(n -> n.getTitle().equals(k.getTitle()))) {
            k.setScore(k.getScore() + 1);
        }
    }
...
}
</pre> 

마지막으로 List의 sort 기능을 사용하여 정렬하였습니다.
<pre>
result.sort((o1, o2) -> {
    // score가 같을 경우 idx가 작은순(먼저 검색결과가 노출된 순서)
    if (o1.getScore() == o2.getScore()) {
        if (o1.getIdx() < o2.getIdx())
            return -1;
        else if (o1.getIdx() > o2.getIdx())
            return 1;
    } else {
        //그렇지 않을 겨우는 스코어가 큰순으로 정렬
        if (o1.getScore() > o2.getScore())
            return -1;
        else if (o1.getScore() < o2.getScore())
            return 1;
    }
    return 0;
});
</pre>

### 2. 대량의 트래픽 처리
대량의 트래픽 처리를 위해 Redis의 캐시 기능을 사용하였고 캐시 유지 시간은 5분으로 정하여 
트랙픽이 몰릴 경우 DB의 부하 및 OpenAPI 호출 빈도를 줄이도록 구현하였습니다.

<pre>
//RedisCacheConfig.java

RedisCacheConfiguration defaultConfig =
    RedisCacheConfiguration.defaultCacheConfig()
            .disableCachingNullValues()
            .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()))
            .entryTtl(Duration.ofMinutes(5L)); // 5분 설정

//LocalSearchServiceImpl.java            
@Cacheable(value = "search", key = "#q")
public List<SearchResultDto> search(String q) {
....생략...
}
</pre> 

### 3. 동시성 문제의 해결
동시성 문제는 다수의 인스턴스에서 실행되었을 때 DB만 사용할 경우 Isolation Level의 문제로 인해 사용자별로 결과가 상의 할 수 있습니다.  
이 문제를 해결하기 위해 Redis의 Sorted Set을 사용하여 구현하였고, 위 2번에서 캐시를 사용하였기 때문에 캐시와 상관없이 저장되도록 캐시를 읽어오기 전에 값을 저장합니다.

최초 구동 시 Redis의 데이터를 DB에 저장 못 했을 경우를 대비하여 Redis에서 DB로 데이터를 저장하고,  
DB에 있는 키워드 상위 10개를 Redis로 로드합니다. 
<pre>
@PostConstruct
private void initPopularKeyword() {
    //서버의 비정상 종료로 인해 DB에 저장 못하고 Redis에 남아 있는 데이터 Save
    saveRedisToDb();
    //DB의 값을 Redis Sorted Set에 로드
    Page<SearchKeyword> findPopular = searchKeywordRepository.findAll(PageRequest.of(0, 10, Sort.Direction.DESC, "cnt"));
    findPopular.getContent().forEach(k -> popularSet.add(REDIS_POPULAR_KEY, k.getKeyword(), k.getCnt()));
}
</pre>

그 이후부터 사용자가 검색하는 키워드를 DB와 Redis에 저장합니다.
<pre>
public void saveKeyword(String keyword) {
    //Redis에 저장
    popularSet.incrementScore(REDIS_POPULAR_KEY, keyword, 1);
    //DB에 저장을 위한 데이터 쌓기
    keywordSaveList.leftPush(REDIS_SAVE_KEYWORD_KEY, keyword);
}
</pre>

이 값을 다시 DB에 저장하기 위해 Spring의 Scheduler를 이용하여 매초 데이터를 저장하도록 합니다.
<pre>
/**
 * DB 저장
 */
@Scheduled(cron = "* * * * * *")
public void saveRedisToDb() {
    //DB에 저장
    List<String> range = keywordSaveList.range(REDIS_SAVE_KEYWORD_KEY, 0, -1);
    if (range != null) {
        keywordSaveList.trim(REDIS_SAVE_KEYWORD_KEY, range.size(), -1);
        Map<String, Integer> keywordMap = new HashMap<>();
        // 동일한 키워드 분류
        range.forEach(r -> {
            int cnt = 1;
            if (keywordMap.containsKey(r)) {
                cnt = keywordMap.get(r) + 1;
            }
            keywordMap.put(r, cnt);
        });

        //DB Save
        keywordMap.keySet().forEach(k -> {
            int cnt = keywordMap.get(k);
            Boolean existsKeyword = searchKeywordRepository.existsByKeyword(k);
            if (existsKeyword)
                searchKeywordRepository.addSearchKeywordCnt(k, cnt);
            else
                searchKeywordRepository.save(
                        SearchKeyword.builder()
                                .keyword(k)
                                .cnt(cnt)
                                .build());
        });
    }
}
</pre>

사용자가 인기 키워드 요청 시 Redis에 저장된 키워드를 가지고 옵니다.  
여기서 주의할 점은 Redis ZSet의 기본 정렬이 오름차순이므로 역순으로 갖고 와야 합니다.
<pre>
 public List<SearchKeywordDto> popularKeyword() {
    Set<ZSetOperations.TypedTuple<String>> populars = popularSet.reverseRangeWithScores(REDIS_KEY, 0, 9);

    if (populars != null) {
        return populars.stream()
                .map(p -> SearchKeywordDto
                        .builder()
                        .keyword(p.getValue())
                        .cnt(Objects.requireNonNull(p.getScore()).intValue())
                        .build())
                .collect(Collectors.toList());
    }
    return new ArrayList<>();
}
</pre>

# 구현 목표
과제의 구현 목표는 다음과 같습니다.

1. 공통사항
   - 동시성 문제 해결
   - 트래픽이 많고, 저장된 데이터가 많은 상황에 대한 대응
   - 에러 처리
2. 회원가입/로그인 API
   - 아이디와 비밀번호로 회원가입
   - 아이디와 비밀번호로 로그인
   - 비밀번호 암호화
   - 로그인 사용자가 다른 API에서 로그인 정보를 확인하는데 사용 가능 하도록 토큰 발행(발행일부터 1일 후 만료)
3. 장소검색 API
   - 키워드 검색 Open API 사용(카카오, 네이버)
   - 각 Open API에서 최대 10씩 추출(단, 네이버는 API에서 최대 5개를 지원하여 5개만 사용)
   - 카카오 API 검색 결과 기준정렬, 네이버와 동일한 결과가 있으면 상위 노출
   - 로그인 한 사용자일 경우 검색 히스토리 저장
   - 검색 키워드 저장(동시성 문제 해결)
4. 내 검색 히스토리 API
   - 나의 검색 히스토리(키워드, 검색 일시)를 최신순으로 표시
5. 인기 키워드 목록 API
   - 사용자가 많이 검색한 순서대로 10개 키워드 제공
   - 키워드, 검색 횟수 표시

# 구현에서 제외
과제 요구사항에서 명시한 기능과 핵심로직 구현에 집중하기 위해 아래 내용은 제외되었습니다.

1. Spring Security를 사용한 전반적인 권한 통제
2. Whitelabel Error Page 
3. 로그인 차단 정첵 미 적용(비밀번호 틀린 횟수로 인한 잠금 처리 등)
4. 비밀번호 정책(영문 대소문자, 숫자, 특수문자 사용 여부 확인 등)
5. 인기 검색어의 기간검색(구현된 방식은 모든 기간의 검색어 기준으로 인기 검색어 표시)

# 구현의 한계점
현재 구현된 과제는 다음과 같은 한계점이 있습니다.
인기 키워드는 계속 누적되므로 과거부터 검색이 많이 된 검색어는 앞으로도 계속 상위 검색어로 유지될 가능성이 큽니다.
이 문제를 해결하기 위해서는 인기 검색어를 기간으로 나누어서 노출한다면 어느 정도 이 문제를 해결 할 수 있다고 보입니다.
또한 인기 키워드를 Redis에 저장하고 있음으로 기간이 길어지고 메모리의 문제가 발생 할 수 있습니다.
이 문제도 첫 번째 한계점과 동일하게 적절한 기간 설정을 한다면 충분히 해결 가능하다고 봅니다.

# 구현 기술 스택
과제를 구현하기 위해서 아래와 같은 기술을 사용하였습니다.

1. Java 11
2. Spring Boot 2.3.5
3. Spring Data JPA
4. Redis

# 설계
과제를 구현하기 위해 아래와 같이 설계하였습니다.

## UseCase
![UseCase](assets.usecase-diagram.png)

## Sequence Diagram
![Sequence Diagram](assets/sequence-diagram.png)

## ERD
![ERD](assets/erd.png)
## Class Diagram
![Class Diagram](assets/class-diagram.png)

## Deployment Diagram
![Deployment Diagram](assets/deployment-diagram.png)

# 프로젝트 실행 방법
애플리케이션을 실행하기 위해서는 다음과 같은 절차를 따라야 합니다.

## 필수 설치 프로그램
1. Java 11
2. Redis
   - Host: 127.0.0.1
   - Port: 6379

## 애플리케이션 실행방법
1. 어플리케이션 시작
<pre>
./gradlew bootRun
</pre>

# 테스트(테스트 코드 기반)
테스트케이스는 통합테스트 1개와 유닛테스트 15개를 작성하여 API와 중요 비지니스로직에 대해서 테스트를 진행하였습니다.

통합테스트 시나리오는 다음과 같습니다.
1. 10명의 사용자가 1초 간격으로 10번의 검색어를 랜덤하게 검색한다.
2. 검색 결과는 Log로 출력한다.
3. 최종적으로 별도의 10명의 사용자가 인기 키워드 목록을 요청한다.
4. 요청 결과는 Log로 출력한다.

위 시나리오를 수행하기 위해 총 10개의 Thread를 생성하여 테스트하였고, 먼저 생성된 순서대로 주문이 발생하는 것을 방지하기 위해 
Thread Priority를 설정하여 랜덤하게 실행되도록 테스트 코드를 구현하였습니다.

## 테스트 환경
- MacBook Pro (13-inch, 2020, Four Thunderbolt 3 ports)
- 2 GHz 쿼드 코어 Intel Core i5
- 16GB 3733 MHz LPDDR4X  
_**테스트 환경에따라 접속 오류가 발생할 수 있습니다.**_

## 테스트 실행 방법
<pre>
./gradlew test
</pre>

[테스트 결과 보기](assets/test-reports/index.html)

## 테스트 로그
![테스트 로그](assets/test-detail.png)

## 전체 테스트 결과
![전체 테스트 결과](assets/test-summary.png)

# 테스트(Http Request 파일 기반)
http-request/ApiTest.http 파일에서 순서대로 테스트를 진행할 수 있다.
주의사항은 사용자 로그인 시 토큰이 발행되는데 이 토큰을 이용하여 '**장소검색**'을 진행해야 '**내 검색 히스토리**'에 저징이 된다.